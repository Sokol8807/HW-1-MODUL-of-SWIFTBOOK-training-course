import Foundation

/*:
 ## Задание 3*
 С помощью блоков `case` определяются возможные значения, которые может принять выражение. Однако Swift позволяет в пределах одного блока case указать не только на значение рассматриваемого параметра, но и на зависимость от какого-либо условия. Данный функционал реализуется с помощью ключевого слова `where` в блоке `case`.
 
 В этом задании вам необходимо отсортировать конфеты M&M's по цвету и по начинке. В первую кучку нужно собрать красные конфеты с шоколадом внутри. Во вторую кучку соберите все желтые конфеты с орехами. А в третью кучку коричневые с шоколадом и зеленые с шоколадом. Нужно реализовать только логику для сортировки конфет. Использовать кортежи при этом не нужно.
 
 */
let candy = "конфета"
let unknowCandyColor = "коричневого"  // сюда ввести цвет конфеты
let unknowCandy = "шоколадом"      // сюда начинку

let redCandyColor = "красного"
let yellowCandyColor = "желтого"
let brownCandyColor = "коричневого"
let greenCandyColor = "зеленого"

let chocolatCandy = "шоколадом"
let natCandy = "орехом"

switch candy {
case _ where unknowCandy == chocolatCandy && unknowCandyColor == redCandyColor:
    print("Эта \(candy) \(redCandyColor) цвета, с \(chocolatCandy) внутри")
case _ where unknowCandy == natCandy && unknowCandyColor == yellowCandyColor:
    print("Эта \(candy) \(yellowCandyColor) цвета, с \(natCandy) внутри")
case _ where unknowCandy == chocolatCandy && (unknowCandyColor == brownCandyColor || unknowCandyColor == greenCandyColor):
    print("Эта \(candy) \(brownCandyColor) или \(greenCandyColor) цвета, с \(chocolatCandy) внутри")
    
default:
    print ("Я не знаю что это за конфета")
}


//: [Ранее: Задание 2](@previous)  |  задание 3 из 3  |
